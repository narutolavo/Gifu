"""{{ cookiecutter.package_name }} - {{ cookiecutter.package_description }}"""
from gifu import gifuu
# __version__ = "1.0.0"
# __author__ = "narutolavo"
# __all__ = ['gifu','main']


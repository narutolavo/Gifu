====
gifu
====

O gifu é programa que pode ser usado como auxilio no estudo de outros idiomas, você pode pegar o texto no idioma desejado e começar a ler, as palavras que vçê não consegui ler, você adiciona o caractere **@** e ele vai da a tradução logo abaixo. ao aperta no botão **criar anki** você gera um arquivo.txt com as palavras estudadas. e depois é só ir no aplicativo do `ANKI`_ e importar.

.. _ANKI: https://ankiweb.net/

Instalação
----------

Para instalar, use o pip3 com o pacote "gifu".

.. code:: bash

    $ pip3 install gifu




import sys
from gifu import gifuu

gifuu.main()
